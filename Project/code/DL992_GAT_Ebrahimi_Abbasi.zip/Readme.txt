#############################################################################
Deep Learning - Spring 2021
Instructor: Dr. Mohammad Reza Mohammadi
Student: Mohammad Ebrahimi, Parsa Abbasi
Iran University of Science and Technology
#############################################################################

The code of the project can also be reviewed directly on Google Colab:
	GAT - Cora
		https://colab.research.google.com/drive/1xBFSXRf0KwCza38IRcRsNuT__B6HXxfN?usp=sharing
	GAT - Reddit:
		https://colab.research.google.com/drive/1oG8sLCCflSYnGmaVSkz9oTSdh60NI5pM?usp=sharing
	GAT - Wiki_CS
		https://colab.research.google.com/drive/170cyAYOTBtuRWx8Cgjlya9FwurhUIm9w?usp=sharing
	GAT - PPI
		https://colab.research.google.com/drive/1lNy4k3U9oMPrs32EgSVbLVEpb93zrPmG?usp=sharing